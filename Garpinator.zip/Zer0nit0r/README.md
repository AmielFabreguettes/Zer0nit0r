# Zer0nit0r

Akinator type app

## Authors

Omar El Faria

Amiel Fabreguettes



